class BankAccount:
        def __init__(self, name, int_rate=0, balance=0):
                self.name = name
                self.int_rate = int_rate
                self.balance = balance
        def deposit(self, amount):
                self.balance += amount
                return self
        def withdraw(self, amount):
                self.balance -= amount
                if self.balance == 0:
                        print("Insufficient funds: You will be charged a $5 fee")
                        self.balance -= 5   
                return self     
        def display_account_info(self):
                print(f'Balance is: {self.balance}')
                return self
        def yield_interest(self):
                if self.balance >0:
                        self.balance += self.balance * self.int_rate
                return self

mia = BankAccount("Mia",0.5, 30)
joe = BankAccount("Joe", 0.65, 20)

mia.deposit(30).deposit(20).deposit(25).withdraw(5).yield_interest().display_account_info()

joe.deposit(50).deposit(100).withdraw(10).withdraw(15).withdraw(10.).withdraw(5).yield_interest().display_account_info()